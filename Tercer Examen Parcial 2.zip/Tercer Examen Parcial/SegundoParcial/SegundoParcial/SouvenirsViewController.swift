//
//  SouvenirsViewController.swift
//  SegundoParcial
//
//  Created by macbook on 4/29/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit

let Price1=260
let Price2=20
class SouvenirsViewController: UIViewController {
    
    
    @IBOutlet weak var Field1: UITextField!
    
    @IBOutlet weak var Field2: UITextField!
    
    @IBOutlet weak var FieldCupon: UITextField!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func ComprarButton(_ sender: UIButton) {
        if Corroborar(text1: Field1.text , text2: Field2.text){
            performSegue(withIdentifier: "CompraSegue", sender: self)
        }
            
    }
    
    func Corroborar(text1:String?, text2:String?)-> Bool{
        if (text1=="" || text2==""){
            return false
        }
        else {
            
            return true
        }
    }
    
    

}
