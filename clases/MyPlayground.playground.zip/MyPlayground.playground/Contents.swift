import Foundation

let arreglo: [Any]=["nombre", 12.0, 1, true]

func recorrer(Arreglo: [Any]){
    
    for item in Arreglo{
        
        if let item = item as? String{
        print("\(item) es una cadena")
        }
        
        else if let item = item as? Double{
        print("\(item) es una cadena")
        }
        
        else if let item = item as? Int{
        print("\(item) es una cadena")
        }
        
        else if let item = item as? Bool{
        print("\(item) es una cadena")
        }
    }
}

recorrer(Arreglo: arreglo)
