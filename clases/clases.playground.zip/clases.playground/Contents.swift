import UIKit

class Shoe:CustomStringConvertible, Equatable {
    static func == (lhs: Shoe, rhs: Shoe) -> Bool {
        if lhs.color==rhs.color{
            return true
        }
        else{
            return false
        }
    }
    
    var description: String{
        return "Description color:\(color) size:\(size) hasLaces:\(hasLaces)"
    }
    
    let size: Int
    let color: String
    let hasLaces: Bool
    init(size:Int, color:String, hasLaces:Bool) {
        self.color=color
        self.size=size
        self.hasLaces=hasLaces
    }
}


let zapato=Shoe(size:20, color: "REd", hasLaces:true)
let huarache=Shoe(size:12, color: "REd", hasLaces:false)
print(zapato)
print(zapato==huarache)
