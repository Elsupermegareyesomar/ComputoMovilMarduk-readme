import UIKit

struct Book{
    var Name: String
    var publicationYear: Int
    
    init?(Name:String, publicationYear:Int?) {
        if let publicationYear=publicationYear{
            self.Name=Name
            self.publicationYear=publicationYear
        }else{
            return nil
        }
    }
}

let firstHarryPotter=Book(Name:"Harry1", publicationYear:1997)

let secondHarryPotter=Book(Name:"Harry2", publicationYear:1998)

let thirdHarryPotter=Book(Name:"Harry3", publicationYear:2000)

let unannoucedBook=Book(Name: "Hary4", publicationYear: nil)

let books=[firstHarryPotter, secondHarryPotter, thirdHarryPotter]


for item in books{
    if let constant=item?.publicationYear{
        print(constant)
    }
    
}


