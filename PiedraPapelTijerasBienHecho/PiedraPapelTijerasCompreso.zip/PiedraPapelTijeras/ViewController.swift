//
//  ViewController.swift
//  PiedraPapelTijeras
//
//  Created by Macbook on 4/5/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let PPT = ["👊","🤚","✌️"]
    @IBOutlet weak var Label: UILabel!
    
    @IBOutlet weak var Label2: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func PiedraAction(_ sender: Any) {
        RandomChoice(userChoice:String(PPT[0]))
    }
    
    @IBAction func PapelAction(_ sender: Any) {
        RandomChoice(userChoice: String(PPT[1]))
    }
    
    @IBAction func TijerasAction(_ sender: Any) {
        RandomChoice(userChoice: String(PPT[2]))
    }
    
    func RandomChoice(userChoice:String){
        let randomChoice = PPT.randomElement()
        Label.text=randomChoice


        if randomChoice==userChoice{
            Label2.text="Empate"
        }
        
        if (userChoice==PPT[0] && randomChoice==PPT[2]) || (userChoice==PPT[1] && randomChoice==PPT[0]) || (userChoice==PPT[2] && randomChoice==PPT[1]){
            Label2.text="Ganaste"
            
        }
        
        if (userChoice==PPT[2] && randomChoice==PPT[0]) || (userChoice==PPT[0] && randomChoice==PPT[1]) || (userChoice==PPT[1] && randomChoice==PPT[2]){
            Label2.text="Perdiste"
            
        }

    }

}

