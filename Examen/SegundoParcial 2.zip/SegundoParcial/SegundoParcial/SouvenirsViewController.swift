//
//  SouvenirsViewController.swift
//  SegundoParcial
//
//  Created by macbook on 4/29/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit

let Price1=10
let Price2=20
class SouvenirsViewController: UIViewController {

    @IBOutlet weak var Price1Label: UILabel!
    
    @IBOutlet weak var Price2Label: UILabel!
    
    @IBOutlet weak var TotalPriceLabel: UILabel!
    
    @IBOutlet weak var Field1: UITextField!
    
    @IBOutlet weak var Field2: UITextField!
    
    @IBOutlet weak var FieldCupon: UITextField!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Price1Label.text="10"
        Price2Label.text="20"
    }
    
    var Unit1 = 0
    var Unit2 = 0
    
    @IBAction func ComprarButton(_ sender: UIButton) {
        if Corroborar(text1: Field1.text , text2: Field2.text){
            TotalPriceLabel.text="Mil"
            performSegue(withIdentifier: "CompraSegue", sender: self)
        }
    }
    
    func Corroborar(text1:String?, text2:String?)-> Bool{
        if (text1=="" || text2==""){
            return false
        }
        
        else {
            return true
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
