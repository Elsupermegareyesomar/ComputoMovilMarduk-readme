//
//  TriviaViewController.swift
//  SegundoParcial
//
//  Created by macbook on 4/29/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {

    @IBOutlet weak var Switch1: UISwitch!
    
    @IBOutlet weak var Switch2: UISwitch!
    
    @IBOutlet weak var Switch3: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func RevisarButton(_ sender: UIButton) {
        if(Switch1.isOn && Switch2.isOn && Switch3.isOn ){
            performSegue(withIdentifier: "CorrectSegue", sender: self)
        }
        else{
            performSegue(withIdentifier: "WrongSegue", sender: self)
        }
    }
    
    
    @IBAction func IntetardeNuevo(_ sender: UIButton) {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
