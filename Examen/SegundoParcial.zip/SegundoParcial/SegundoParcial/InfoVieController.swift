//
//  InfoVieController.swift
//  SegundoParcial
//
//  Created by macbook on 4/29/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit
struct Album {
    var Nombre: String
    var Fecha: String
    var Dato: String
}

var Album1=Album(Nombre: "String1", Fecha: "1", Dato: "String1")
var Album2=Album(Nombre: "String2", Fecha: "2", Dato: "String2")
var Album3=Album(Nombre: "String3", Fecha: "3", Dato: "String3")

class InfoVieController: UIViewController {

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
