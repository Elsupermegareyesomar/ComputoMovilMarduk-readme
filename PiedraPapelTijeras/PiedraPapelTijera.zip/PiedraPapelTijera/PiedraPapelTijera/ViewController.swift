//
//  ViewController.swift
//  PiedraPapelTijera
//
//  Created by macbook on 3/25/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var View: UIView!
    
    @IBOutlet weak var View2: UIView!
    
    @IBOutlet weak var Piedra: UIButton!
    
    @IBOutlet weak var Papel: UIButton!
    
    @IBOutlet weak var Tijeras: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func PiedraAction(_ sender: Any) {
    }
    
    @IBAction func PapelAction(_ sender: Any) {
    }
    
    @IBAction func TijeraAction(_ sender: Any) {
    }
    
    func 
}

